
public class Descida extends Tro�o{

}
