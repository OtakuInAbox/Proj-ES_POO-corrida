
public class Subida extends Tro�o{

}
