
public abstract class Cartas {

}
