
public class Suspensao extends Carro{

}
