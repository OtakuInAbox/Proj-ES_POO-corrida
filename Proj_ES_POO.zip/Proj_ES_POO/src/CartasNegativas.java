
public class CartasNegativas extends Cartas{

}
