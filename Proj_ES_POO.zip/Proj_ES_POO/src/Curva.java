
public class Curva extends Tro�o{

}
