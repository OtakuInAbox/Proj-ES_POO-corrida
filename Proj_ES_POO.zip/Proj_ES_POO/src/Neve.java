
public class Neve extends Piso{

}
