
public abstract class Tro�o {

}
