
public class CartasPositivas extends Cartas{

}
