
public class Reta extends Tro�o{

}
