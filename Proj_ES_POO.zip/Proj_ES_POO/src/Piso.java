
public abstract class Piso extends Tro�o{

	
}
