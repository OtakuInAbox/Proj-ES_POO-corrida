
public class Pneus extends Carro{

}
